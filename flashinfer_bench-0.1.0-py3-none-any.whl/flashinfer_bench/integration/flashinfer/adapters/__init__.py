"""Adapters for flashinfer integration."""
